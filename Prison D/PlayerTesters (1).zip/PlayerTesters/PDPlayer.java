public interface PDPlayer
{
    public String chooseCorD(String opponentsLastMove);
    public String getAuthor();
    public String toString();
}
